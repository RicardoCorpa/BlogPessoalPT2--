package org.generation.blogPessoal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlogPessoalRicardoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlogPessoalRicardoApplication.class, args);
	}

}
